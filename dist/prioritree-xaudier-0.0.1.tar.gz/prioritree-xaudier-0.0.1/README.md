# Package Description

This package shows a graphical interface for project management.
A Tree View allows you to organize tasks in a branching architecture.
A List View allows you to sort all items according to a priority criterion.
